// Sistema de armazenamento das mensagens
let messageData = {
  categories: {}
};

// Posição do botão
let buttonPosition = {
  bottom: '20px',
  right: '20px',
  top: 'auto',
  left: 'auto'
};

// Variáveis para controle do drag (apenas no editor)
let draggedItem = null;
let draggedSubItem = null;
let draggedOverItem = null;
let draggedOverSubItem = null;

// Mapa de ícones padrão para categorias
const categoryIcons = {
  'Gravação': '✍️',
  'Desconto 50%': '💰',
  'Mercado Pago': '💳',
  'Troca de Endereço': '🏠',
  'Troca de Aliança': '💍',
  'Menos Usadas': '❓',
  'default': '📂'
};

// Variável para armazenar a categoria atualmente expandida por clique
let openCategoryDiv = null;

// ============================================================
// ARMAZENAMENTO
// ============================================================

function loadData() {
  const saved = localStorage.getItem('mr-messages');
  if (saved) {
    try { messageData = JSON.parse(saved); } catch (e) { console.error('Erro ao carregar dados:', e); }
  }
  const savedPosition = localStorage.getItem('mr-button-position');
  if (savedPosition) {
    try { buttonPosition = JSON.parse(savedPosition); } catch (e) {}
  }
}

function saveData() {
  localStorage.setItem('mr-messages', JSON.stringify(messageData));
}

function saveButtonPosition(top, left) {
  const windowWidth = window.innerWidth;
  const windowHeight = window.innerHeight;
  const distanceToRight = windowWidth - left;
  const distanceToBottom = windowHeight - top;
  if (distanceToRight < windowWidth / 2) { buttonPosition.right = distanceToRight + 'px'; buttonPosition.left = 'auto'; }
  else { buttonPosition.left = left + 'px'; buttonPosition.right = 'auto'; }
  if (distanceToBottom < windowHeight / 2) { buttonPosition.bottom = distanceToBottom + 'px'; buttonPosition.top = 'auto'; }
  else { buttonPosition.top = top + 'px'; buttonPosition.bottom = 'auto'; }
  localStorage.setItem('mr-button-position', JSON.stringify(buttonPosition));
}

// ============================================================
// BOTÃO FLUTUANTE
// ============================================================

function renderButton() {
  if (document.getElementById('mr-button')) return;
  loadData();

  const btn = document.createElement('div');
  btn.id = 'mr-button';
  btn.textContent = '✉️';
  btn.style.cssText = `
    position: fixed;
    top: ${buttonPosition.top};
    left: ${buttonPosition.left};
    bottom: ${buttonPosition.bottom};
    right: ${buttonPosition.right};
    width: 50px; height: 50px;
    background: #007bff; color: white;
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    cursor: pointer; font-size: 20px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    z-index: 10000; user-select: none;
  `;

  const drag = document.createElement('div');
  drag.textContent = '⋮';
  drag.style.cssText = `
    cursor: move; position: absolute; top: -10px; left: -10px;
    background: #ccc; border-radius: 4px; padding: 2px 4px;
    font-size: 12px; color: #666;
  `;
  drag.title = 'Arraste para mover';
  btn.appendChild(drag);

  let offsetX = 0, offsetY = 0, isDragging = false;
  drag.onmousedown = (e) => {
    e.stopPropagation();
    isDragging = true;
    offsetX = e.clientX - btn.getBoundingClientRect().left;
    offsetY = e.clientY - btn.getBoundingClientRect().top;
    document.onmousemove = (e) => {
      if (!isDragging) return;
      const newLeft = e.clientX - offsetX;
      const newTop = e.clientY - offsetY;
      const maxX = window.innerWidth - btn.offsetWidth;
      const maxY = window.innerHeight - btn.offsetHeight;
      btn.style.top = Math.max(0, Math.min(newTop, maxY)) + 'px';
      btn.style.left = Math.max(0, Math.min(newLeft, maxX)) + 'px';
      btn.style.bottom = 'auto'; btn.style.right = 'auto';
    };
    document.onmouseup = (e) => {
      if (isDragging) {
        isDragging = false;
        const rect = btn.getBoundingClientRect();
        saveButtonPosition(rect.top, rect.left);
        const menu = document.getElementById('mr-menu');
        if (menu && menu.style.visibility === 'visible') positionMenu();
      }
      document.onmousemove = null; document.onmouseup = null;
    };
  };

  btn.onclick = (e) => { if (!isDragging) { e.stopPropagation(); toggleMenu(); } };
  document.body.appendChild(btn);
  renderMenu();
  renderEditor();
}

// ============================================================
// MENU PRINCIPAL
// ============================================================

function renderMenu() {
  if (document.getElementById('mr-menu')) return;

  const menu = document.createElement('div');
  menu.id = 'mr-menu';
  menu.style.cssText = `
    position: fixed; width: 300px;
    background: white; border: 1px solid #ddd;
    border-radius: 8px; box-shadow: 0 4px 20px rgba(0,0,0,0.15);
    z-index: 10001; visibility: hidden; opacity: 0;
    transform: scale(0.95);
    transition: opacity 0.5s ease, transform 0.5s ease, visibility 0.5s;
  `;

  const header = document.createElement('div');
  header.style.cssText = `
    padding: 12px 16px; border-bottom: 1px solid #eee;
    background: #f8f9fa; border-radius: 8px 8px 0 0;
    display: flex; justify-content: space-between; align-items: center;
  `;

  const title = document.createElement('strong');
  title.textContent = 'Mensagens Rápidas';
  title.style.color = '#333';

  const editBtn = document.createElement('button');
  editBtn.textContent = '⚙️ Editar';
  editBtn.style.cssText = `
    background: #007bff; color: white; border: none;
    padding: 4px 8px; border-radius: 4px; cursor: pointer; font-size: 12px;
  `;
  editBtn.onclick = () => openEditor();

  header.appendChild(title);
  header.appendChild(editBtn);
  menu.appendChild(header);

  const content = document.createElement('div');
  content.id = 'mr-menu-content';
  content.style.padding = '8px';
  content.style.maxHeight = 'calc(80vh - 50px)';
  content.style.overflowY = 'auto';
  menu.appendChild(content);

  document.body.appendChild(menu);
  updateMenuContent();
}

function positionMenu() {
  const menu = document.getElementById('mr-menu');
  const btn = document.getElementById('mr-button');
  if (!menu || !btn) return;

  const btnRect = btn.getBoundingClientRect();
  menu.style.visibility = 'hidden'; menu.style.opacity = '0'; menu.style.display = 'block';
  const menuWidth = menu.offsetWidth;
  const menuHeight = menu.offsetHeight;
  menu.style.display = 'block';

  const windowWidth = window.innerWidth;
  const windowHeight = window.innerHeight;
  const padding = 10;
  let left, top;

  if (btnRect.right + menuWidth + padding <= windowWidth) left = btnRect.right + padding;
  else if (btnRect.left - menuWidth - padding >= 0) left = btnRect.left - menuWidth - padding;
  else left = Math.max(padding, (windowWidth - menuWidth) / 2);

  if (btnRect.top + menuHeight + padding <= windowHeight) top = btnRect.top;
  else if (btnRect.bottom - menuHeight - padding >= 0) top = btnRect.bottom - menuHeight;
  else { top = Math.max(padding, (windowHeight - menuHeight) / 2); top = Math.min(top, windowHeight - menuHeight - padding); }

  menu.style.left = left + 'px';
  menu.style.top = top + 'px';
  menu.style.transformOrigin = 'center center';
}

const openCategory = (currentCategoryDiv, subcategoriesDiv, arrow) => {
  if (openCategoryDiv && openCategoryDiv !== currentCategoryDiv) {
    const prevSubDiv = openCategoryDiv.querySelector('.subcategories-list');
    const prevArrow = openCategoryDiv.querySelector('.arrow-icon');
    if (prevSubDiv) { prevSubDiv.style.maxHeight = '0'; prevSubDiv.style.opacity = '0'; }
    if (prevArrow) prevArrow.style.transform = 'rotate(0deg)';
  }
  subcategoriesDiv.style.maxHeight = '500px';
  subcategoriesDiv.style.opacity = '1';
  arrow.style.transform = 'rotate(180deg)';
  positionMenu();
  openCategoryDiv = currentCategoryDiv;
};

const closeCategory = (subcategoriesDiv, arrow) => {
  subcategoriesDiv.style.maxHeight = '0';
  subcategoriesDiv.style.opacity = '0';
  arrow.style.transform = 'rotate(0deg)';
  positionMenu();
  openCategoryDiv = null;
};

function updateMenuContent() {
  const content = document.getElementById('mr-menu-content');
  if (!content) return;
  content.innerHTML = '';

  if (Object.keys(messageData.categories).length === 0) {
    const empty = document.createElement('div');
    empty.style.cssText = 'text-align: center; color: #666; padding: 20px; font-style: italic;';
    empty.textContent = 'Nenhuma mensagem cadastrada. Clique em "Editar" para adicionar.';
    content.appendChild(empty);
    return;
  }

  Object.entries(messageData.categories).forEach(([categoryName, category]) => {
    const categoryDiv = document.createElement('div');
    categoryDiv.style.marginBottom = '8px';

    const categoryBtn = document.createElement('div');
    categoryBtn.style.cssText = `
      padding: 8px 12px; background: #f0f0f0; color: #333;
      border-radius: 4px; cursor: pointer; font-weight: bold;
      display: flex; justify-content: space-between; align-items: center; gap: 8px;
    `;

    const categoryTextContainer = document.createElement('div');
    categoryTextContainer.style.cssText = 'display: flex; align-items: center; gap: 8px;';

    const categoryIconSpan = document.createElement('span');
    categoryIconSpan.textContent = category.icon || categoryIcons[categoryName] || categoryIcons['default'];
    categoryIconSpan.style.color = category.color || '#333';
    categoryIconSpan.style.fontSize = '18px';

    const categoryNameSpan = document.createElement('span');
    categoryNameSpan.textContent = categoryName;

    categoryTextContainer.appendChild(categoryIconSpan);
    categoryTextContainer.appendChild(categoryNameSpan);
    categoryBtn.appendChild(categoryTextContainer);

    const arrow = document.createElement('span');
    arrow.textContent = '▼';
    arrow.style.transition = 'transform 0.2s';
    arrow.style.color = '#333';
    arrow.classList.add('arrow-icon');
    categoryBtn.appendChild(arrow);

    const subcategoriesDiv = document.createElement('div');
    subcategoriesDiv.style.cssText = `
      margin-top: 4px; margin-left: 12px; overflow: hidden;
      max-height: 0; opacity: 0;
      transition: max-height 0.5s ease-out, opacity 0.5s ease-out;
    `;
    subcategoriesDiv.classList.add('subcategories-list');

    Object.entries(category.subcategories || {}).forEach(([subName, subItem]) => {
      const subMessage = typeof subItem === 'string' ? subItem : subItem.message;
      const subColor = (typeof subItem === 'object' && subItem.color) ? subItem.color : (category.color || '#007bff');

      const subBtn = document.createElement('div');
      subBtn.style.cssText = `
        padding: 6px 12px; background: white; color: #333;
        border-radius: 4px; cursor: pointer; margin-bottom: 2px;
        border: 1px solid ${subColor}; border-left: 5px solid ${subColor};
      `;
      subBtn.textContent = subName;
      subBtn.onclick = (e) => { e.stopPropagation(); insertMessage(subMessage); toggleMenu(); };
      subcategoriesDiv.appendChild(subBtn);
    });

    categoryBtn.onclick = () => {
      const isVisible = parseFloat(subcategoriesDiv.style.maxHeight) > 0;
      if (isVisible) closeCategory(subcategoriesDiv, arrow);
      else openCategory(categoryDiv, subcategoriesDiv, arrow);
    };

    categoryDiv.appendChild(categoryBtn);
    categoryDiv.appendChild(subcategoriesDiv);
    content.appendChild(categoryDiv);
  });
}

function toggleMenu() {
  const menu = document.getElementById('mr-menu');
  if (!menu) return;
  const isVisible = menu.style.visibility === 'visible';
  if (isVisible) {
    menu.style.opacity = '0';
    menu.style.transform = 'scale(0.95)';
    menu.addEventListener('transitionend', function handler() {
      menu.style.visibility = 'hidden';
      menu.removeEventListener('transitionend', handler);
    });
    if (openCategoryDiv) {
      const prevSubDiv = openCategoryDiv.querySelector('.subcategories-list');
      const prevArrow = openCategoryDiv.querySelector('.arrow-icon');
      if (prevSubDiv) { prevSubDiv.style.maxHeight = '0'; prevSubDiv.style.opacity = '0'; }
      if (prevArrow) prevArrow.style.transform = 'rotate(0deg)';
      openCategoryDiv = null;
    }
  } else {
    menu.style.visibility = 'visible';
    menu.style.opacity = '1';
    menu.style.transform = 'scale(1)';
    updateMenuContent();
    positionMenu();
  }
}

// ============================================================
// EDITOR DE MENSAGENS
// ============================================================

function renderEditor() {
  if (document.getElementById('mr-editor')) return;

  // Overlay escuro
  const overlay = document.createElement('div');
  overlay.id = 'mr-editor-overlay';
  overlay.style.cssText = `
    position: fixed; inset: 0;
    background: rgba(0,0,0,0.5);
    z-index: 10001; display: none;
  `;
  overlay.onclick = closeEditor;
  document.body.appendChild(overlay);

  const editor = document.createElement('div');
  editor.id = 'mr-editor';
  editor.style.cssText = `
    position: fixed;
    top: 50%; left: 50%;
    transform: translate(-50%, -50%);
    width: 620px; max-width: 96vw; max-height: 92vh;
    background: #f4f6f9;
    border-radius: 12px;
    box-shadow: 0 12px 40px rgba(0,0,0,0.35);
    display: none; flex-direction: column;
    z-index: 10002; overflow: hidden;
  `;

  editor.innerHTML = `
    <!-- HEADER com todos os controles -->
    <div style="
      background: linear-gradient(135deg, #3483fa, #2968c8);
      padding: 12px 16px;
      display: flex; align-items: center; justify-content: space-between;
      gap: 8px; flex-shrink: 0; flex-wrap: wrap;
    ">
      <span style="color:white; font-size:15px; font-weight:700; white-space:nowrap;">
        ✏️ Editor de Mensagens
      </span>
      <div style="display:flex; gap:6px; align-items:center; flex-wrap:wrap; justify-content:flex-end;">

        <div id="gdrive-status" style="
          font-size:11px; color:rgba(255,255,255,0.9);
          background:rgba(255,255,255,0.15);
          padding:3px 10px; border-radius:20px; white-space:nowrap;
        ">⏳ Verificando...</div>

        <button id="btn-google-login" style="
          background:white; color:#3483fa; border:none;
          padding:5px 11px; border-radius:6px; cursor:pointer;
          font-size:12px; font-weight:600;
          display:flex; align-items:center; gap:5px; white-space:nowrap;
        ">
          <svg width="13" height="13" viewBox="0 0 48 48">
            <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
            <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
            <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
            <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.18 1.48-4.97 2.31-8.16 2.31-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
          </svg>
          Conectar Google
        </button>

        <button id="btn-google-logout" style="
          display:none; background:rgba(255,255,255,0.2); color:white;
          border:1px solid rgba(255,255,255,0.4);
          padding:5px 10px; border-radius:6px; cursor:pointer;
          font-size:11px; white-space:nowrap;
        ">Sair</button>

        <button id="export-drive" style="
          background:#34A853; color:white; border:none;
          padding:5px 11px; border-radius:6px; cursor:pointer;
          font-size:12px; font-weight:600; white-space:nowrap;
        ">☁️ Salvar no Drive</button>

        <button id="import-drive" style="
          background:#FBBC05; color:#333; border:none;
          padding:5px 11px; border-radius:6px; cursor:pointer;
          font-size:12px; font-weight:600; white-space:nowrap;
        ">📥 Importar do Drive</button>

        <button id="export-data" style="
          background:rgba(255,255,255,0.15); color:white;
          border:1px solid rgba(255,255,255,0.3);
          padding:5px 10px; border-radius:6px; cursor:pointer;
          font-size:11px; white-space:nowrap;
        ">⬇️ Baixar JSON</button>

        <button id="import-data" style="
          background:rgba(255,255,255,0.15); color:white;
          border:1px solid rgba(255,255,255,0.3);
          padding:5px 10px; border-radius:6px; cursor:pointer;
          font-size:11px; white-space:nowrap;
        ">📂 Carregar JSON</button>

        <input type="file" id="file-input" accept=".json" style="display:none;">

        <button id="close-editor" style="
          background:rgba(255,255,255,0.15); color:white;
          border:1px solid rgba(255,255,255,0.3);
          width:28px; height:28px; border-radius:6px;
          cursor:pointer; font-size:15px;
          display:flex; align-items:center; justify-content:center; flex-shrink:0;
        ">✕</button>
      </div>
    </div>

    <!-- CORPO com scroll -->
    <div style="overflow-y:auto; padding:14px; display:flex; flex-direction:column; gap:12px; flex:1;">

      <!-- Nova Categoria -->
      <div style="background:white; border-radius:8px; padding:14px; border:1px solid #e0e4ea;">
        <div style="font-weight:700; color:#2968c8; margin-bottom:10px; font-size:12px; text-transform:uppercase; letter-spacing:.6px;">
          📁 Nova Categoria
        </div>
        <div style="display:grid; grid-template-columns:1fr 90px 50px; gap:8px; align-items:end;">
          <div>
            <label style="font-size:11px; color:#888; display:block; margin-bottom:3px;">Nome</label>
            <input type="text" id="new-category" placeholder="Ex: Troca de Aliança"
              style="width:100%; padding:8px; border:1px solid #ddd; border-radius:6px; font-size:13px; box-sizing:border-box;">
          </div>
          <div>
            <label style="font-size:11px; color:#888; display:block; margin-bottom:3px;">Ícone (emoji)</label>
            <input type="text" id="new-category-icon" placeholder="💍"
              style="width:100%; padding:8px; border:1px solid #ddd; border-radius:6px; font-size:13px; text-align:center; box-sizing:border-box;">
          </div>
          <div>
            <label style="font-size:11px; color:#888; display:block; margin-bottom:3px;">Cor</label>
            <input type="color" id="new-category-color" value="#007bff"
              style="width:100%; height:36px; border:1px solid #ddd; border-radius:6px; cursor:pointer; padding:2px; box-sizing:border-box;">
          </div>
        </div>
        <button id="add-category" style="
          margin-top:10px; background:#28a745; color:white;
          border:none; padding:8px 18px; border-radius:6px;
          cursor:pointer; font-size:13px; font-weight:600;
        ">+ Adicionar Categoria</button>
      </div>

      <!-- Nova Mensagem -->
      <div style="background:white; border-radius:8px; padding:14px; border:1px solid #e0e4ea;">
        <div style="font-weight:700; color:#2968c8; margin-bottom:10px; font-size:12px; text-transform:uppercase; letter-spacing:.6px;">
          💬 Nova Mensagem
        </div>
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px; margin-bottom:8px;">
          <div>
            <label style="font-size:11px; color:#888; display:block; margin-bottom:3px;">Categoria</label>
            <select id="category-select"
              style="width:100%; padding:8px; border:1px solid #ddd; border-radius:6px; font-size:13px; box-sizing:border-box;">
              <option value="">Selecione...</option>
            </select>
          </div>
          <div>
            <label style="font-size:11px; color:#888; display:block; margin-bottom:3px;">Nome da mensagem</label>
            <input type="text" id="new-subcategory" placeholder="Ex: Confirmação de troca"
              style="width:100%; padding:8px; border:1px solid #ddd; border-radius:6px; font-size:13px; box-sizing:border-box;">
          </div>
        </div>
        <div style="margin-bottom:8px; display:flex; align-items:center; gap:10px;">
          <label style="font-size:11px; color:#888;">Cor da linha lateral:</label>
          <input type="color" id="new-subcategory-color" value="#007bff"
            style="width:50px; height:30px; border:1px solid #ddd; border-radius:6px; cursor:pointer; padding:2px;">
        </div>
        <div>
          <label style="font-size:11px; color:#888; display:block; margin-bottom:3px;">Texto da mensagem</label>
          <textarea id="subcategory-message"
            placeholder="Digite a mensagem... Use [NOME_CLIENTE] para inserir o nome automaticamente."
            style="width:100%; height:88px; padding:8px; border:1px solid #ddd; border-radius:6px; resize:vertical; font-size:13px; line-height:1.5; box-sizing:border-box;"></textarea>
        </div>
        <div style="display:flex; justify-content:space-between; align-items:center; margin-top:10px;">
          <button id="add-subcategory" style="
            background:#007bff; color:white; border:none;
            padding:8px 18px; border-radius:6px; cursor:pointer;
            font-size:13px; font-weight:600;
          ">+ Adicionar Mensagem</button>
          <span style="font-size:11px; color:#aaa;">💡 [NOME_CLIENTE] será substituído automaticamente</span>
        </div>
      </div>

      <!-- Mensagens Cadastradas -->
      <div style="background:white; border-radius:8px; padding:14px; border:1px solid #e0e4ea;">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
          <div style="font-weight:700; color:#2968c8; font-size:12px; text-transform:uppercase; letter-spacing:.6px;">
            📋 Mensagens Cadastradas
            <span style="font-size:10px; color:#aaa; font-weight:400; text-transform:none; margin-left:4px;">(arraste para reordenar)</span>
          </div>
          <button id="clear-all" style="
            background:#dc3545; color:white; border:none;
            padding:5px 12px; border-radius:6px; cursor:pointer; font-size:11px;
          ">🗑️ Limpar Tudo</button>
        </div>
        <div id="items-list"></div>
      </div>

    </div>
  `;

  document.body.appendChild(editor);
  setupEditorEvents();
}

function setupEditorEvents() {
  document.getElementById('add-category').onclick = addCategory;
  document.getElementById('add-subcategory').onclick = addSubcategory;
  document.getElementById('close-editor').onclick = closeEditor;
  document.getElementById('clear-all').onclick = clearAllData;

  // JSON local
  document.getElementById('export-data').onclick = exportData;
  document.getElementById('import-data').onclick = () => document.getElementById('file-input').click();
  document.getElementById('file-input').addEventListener('change', handleFileImport);

  // Google Drive
  document.getElementById('btn-google-login').onclick = googleLogin;
  document.getElementById('btn-google-logout').onclick = googleLogout;
  document.getElementById('export-drive').onclick = exportToDrive;
  document.getElementById('import-drive').onclick = importFromDrive;

  checkGoogleAuthStatus();
}

function openEditor() {
  const editor = document.getElementById('mr-editor');
  if (!editor) return;
  editor.style.display = 'flex';
  const overlay = document.getElementById('mr-editor-overlay');
  if (overlay) overlay.style.display = 'block';
  updateCategorySelect();
  updateItemsList();
  const menu = document.getElementById('mr-menu');
  if (menu && menu.style.visibility === 'visible') toggleMenu();
}

function closeEditor() {
  const editor = document.getElementById('mr-editor');
  if (editor) editor.style.display = 'none';
  const overlay = document.getElementById('mr-editor-overlay');
  if (overlay) overlay.style.display = 'none';
}

// ============================================================
// GOOGLE DRIVE
// ============================================================

const GDRIVE_FILE_NAME = 'passo-largo-mensagens.json';

function setDriveStatus(msg, color) {
  const el = document.getElementById('gdrive-status');
  if (el) { el.textContent = msg; el.style.color = color || 'rgba(255,255,255,0.9)'; }
}

function checkGoogleAuthStatus() {
  chrome.runtime.sendMessage({ action: 'gdrive_check_auth' }, (res) => {
    if (chrome.runtime.lastError || !res) return setDriveStatus('❌ Erro de conexão');
    updateGoogleUI(res.loggedIn, res.email);
  });
}

function updateGoogleUI(loggedIn, email) {
  const loginBtn  = document.getElementById('btn-google-login');
  const logoutBtn = document.getElementById('btn-google-logout');
  if (!loginBtn || !logoutBtn) return;
  if (loggedIn) {
    loginBtn.style.display  = 'none';
    logoutBtn.style.display = 'flex';
    setDriveStatus('✅ ' + (email ? email.split('@')[0] : 'Conectado'));
  } else {
    loginBtn.style.display  = 'flex';
    logoutBtn.style.display = 'none';
    setDriveStatus('🔒 Não conectado');
  }
}

function googleLogin() {
  setDriveStatus('⏳ Aguardando login...');
  chrome.runtime.sendMessage({ action: 'gdrive_login' }, (res) => {
    if (chrome.runtime.lastError || !res) return setDriveStatus('❌ Erro');
    if (res.error) return setDriveStatus('❌ ' + res.error);
    updateGoogleUI(res.loggedIn, res.email);
  });
}

function googleLogout() {
  chrome.runtime.sendMessage({ action: 'gdrive_logout' }, () => updateGoogleUI(false));
}

function exportToDrive() {
  setDriveStatus('⏳ Salvando no Drive...');
  const data = JSON.stringify(messageData, null, 2);
  chrome.runtime.sendMessage({ action: 'gdrive_export', data, fileName: GDRIVE_FILE_NAME }, (res) => {
    if (chrome.runtime.lastError || !res) return setDriveStatus('❌ Erro ao salvar');
    if (res.error) {
      if (res.needsLogin) return setDriveStatus('🔒 Faça login primeiro');
      return setDriveStatus('❌ ' + res.error);
    }
    setDriveStatus('✅ Salvo no Drive!');
    setTimeout(checkGoogleAuthStatus, 3000);
  });
}

function importFromDrive() {
  setDriveStatus('⏳ Buscando no Drive...');
  chrome.runtime.sendMessage({ action: 'gdrive_import', fileName: GDRIVE_FILE_NAME }, (res) => {
    if (chrome.runtime.lastError || !res) return setDriveStatus('❌ Erro ao buscar');
    if (res.error) {
      if (res.needsLogin) return setDriveStatus('🔒 Faça login primeiro');
      if (res.notFound) return setDriveStatus('⚠️ Nenhum backup no Drive');
      return setDriveStatus('❌ ' + res.error);
    }
    try {
      const imported = JSON.parse(res.data);
      if (!imported.categories) throw new Error('Formato inválido');
      if (confirm('Substituir suas mensagens pelo backup do Drive?')) {
        messageData = imported;
        saveData();
        updateCategorySelect();
        updateItemsList();
        setDriveStatus('✅ Importado com sucesso!');
        setTimeout(checkGoogleAuthStatus, 3000);
      } else {
        setDriveStatus('↩️ Cancelado');
        setTimeout(checkGoogleAuthStatus, 2000);
      }
    } catch(e) {
      setDriveStatus('❌ Arquivo inválido: ' + e.message);
    }
  });
}

// ============================================================
// EXPORTAR / IMPORTAR JSON LOCAL
// ============================================================

function exportData() {
  const dataStr = JSON.stringify(messageData, null, 2);
  const dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);
  const link = document.createElement('a');
  link.setAttribute('href', dataUri);
  link.setAttribute('download', 'backup-mensagens.json');
  link.click();
}

function handleFileImport(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const importedData = JSON.parse(e.target.result);
      if (!importedData.categories) throw new Error('Formato de arquivo inválido');
      for (const catName in importedData.categories) {
        const category = importedData.categories[catName];
        if (category.subcategories) {
          for (const subName in category.subcategories) {
            let subItem = category.subcategories[subName];
            if (typeof subItem === 'string') category.subcategories[subName] = { message: subItem, color: '#007bff' };
            if (!category.subcategories[subName].color) category.subcategories[subName].color = '#007bff';
          }
        }
        if (!category.color) category.color = '#007bff';
        if (!category.icon) category.icon = categoryIcons[catName] || categoryIcons['default'];
      }
      if (confirm('Deseja substituir suas mensagens atuais pelas importadas?')) {
        messageData = importedData;
        saveData();
        updateCategorySelect();
        updateItemsList();
        alert('Mensagens importadas com sucesso!');
      }
    } catch (error) {
      alert('Erro ao importar arquivo: ' + error.message);
    }
  };
  reader.readAsText(file);
  event.target.value = '';
}

// ============================================================
// CRUD CATEGORIAS E SUBCATEGORIAS
// ============================================================

function updateCategorySelect() {
  const select = document.getElementById('category-select');
  if (!select) return;
  select.innerHTML = '<option value="">Selecione...</option>';
  Object.keys(messageData.categories).forEach(categoryName => {
    const option = document.createElement('option');
    option.value = categoryName;
    option.textContent = categoryName;
    select.appendChild(option);
  });
}

function addCategory() {
  const input = document.getElementById('new-category');
  const iconInput = document.getElementById('new-category-icon');
  const colorInput = document.getElementById('new-category-color');
  const categoryName = input.value.trim();
  const categoryIcon = iconInput.value.trim();
  const categoryColor = colorInput.value;

  if (!categoryName) { alert('Digite um nome para a categoria'); return; }
  if (messageData.categories[categoryName]) { alert('Categoria já existe'); return; }

  messageData.categories[categoryName] = {
    subcategories: {},
    color: categoryColor,
    icon: categoryIcon || categoryIcons[categoryName] || categoryIcons['default']
  };
  saveData();
  input.value = ''; iconInput.value = ''; colorInput.value = '#007bff';
  updateCategorySelect();
  updateItemsList();
  alert('Categoria adicionada com sucesso!');
}

function addSubcategory() {
  const categoryName = document.getElementById('category-select').value;
  const subcategoryName = document.getElementById('new-subcategory').value.trim();
  const message = document.getElementById('subcategory-message').value.trim();
  const subcategoryColor = document.getElementById('new-subcategory-color').value;

  if (!categoryName) { alert('Selecione uma categoria'); return; }
  if (!subcategoryName) { alert('Digite um nome para a mensagem'); return; }
  if (!message) { alert('Digite o texto da mensagem'); return; }
  if (messageData.categories[categoryName].subcategories[subcategoryName]) { alert('Mensagem já existe nessa categoria'); return; }

  messageData.categories[categoryName].subcategories[subcategoryName] = { message, color: subcategoryColor };
  saveData();
  document.getElementById('new-subcategory').value = '';
  document.getElementById('subcategory-message').value = '';
  document.getElementById('new-subcategory-color').value = '#007bff';
  updateItemsList();
  alert('Mensagem adicionada com sucesso!');
}

function updateItemsList() {
  const list = document.getElementById('items-list');
  if (!list) return;
  list.innerHTML = '';

  Object.keys(messageData.categories).forEach(categoryName => {
    const category = messageData.categories[categoryName];

    const categoryDiv = document.createElement('div');
    categoryDiv.style.cssText = `
      margin-bottom: 12px; padding: 8px;
      border: 1px solid #ddd; border-radius: 6px;
      background: #f8f9fa; color: #333;
    `;
    categoryDiv.draggable = true;
    categoryDiv.dataset.category = categoryName;

    categoryDiv.addEventListener('dragstart', (e) => { draggedItem = categoryName; e.target.style.opacity = '0.5'; });
    categoryDiv.addEventListener('dragend', (e) => { e.target.style.opacity = '1'; draggedItem = null; draggedOverItem = null; });
    categoryDiv.addEventListener('dragover', (e) => {
      e.preventDefault();
      if (draggedItem && draggedItem !== categoryName) { draggedOverItem = categoryName; e.target.style.borderTop = '3px solid #007bff'; }
    });
    categoryDiv.addEventListener('dragleave', (e) => { e.target.style.borderTop = '1px solid #ddd'; });
    categoryDiv.addEventListener('drop', (e) => {
      e.preventDefault();
      e.target.style.borderTop = '1px solid #ddd';
      if (draggedItem && draggedOverItem && draggedItem !== draggedOverItem) {
        const arr = Object.entries(messageData.categories);
        const di = arr.findIndex(([n]) => n === draggedItem);
        const oi = arr.findIndex(([n]) => n === draggedOverItem);
        const [removed] = arr.splice(di, 1);
        arr.splice(oi, 0, removed);
        messageData.categories = {};
        arr.forEach(([n, d]) => { messageData.categories[n] = d; });
        saveData(); updateItemsList();
      }
      draggedItem = null; draggedOverItem = null;
    });

    const categoryHeader = document.createElement('div');
    categoryHeader.style.cssText = 'display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; cursor:move;';

    const categoryTitleContainer = document.createElement('div');
    categoryTitleContainer.style.cssText = 'display:flex; align-items:center; gap:8px;';

    const iconSpan = document.createElement('span');
    iconSpan.textContent = category.icon || categoryIcons[categoryName] || categoryIcons['default'];
    iconSpan.style.cssText = `color:${category.color || '#007bff'}; font-size:18px;`;

    const nameSpan = document.createElement('strong');
    nameSpan.textContent = categoryName;

    categoryTitleContainer.appendChild(iconSpan);
    categoryTitleContainer.appendChild(nameSpan);
    categoryHeader.appendChild(categoryTitleContainer);

    const categoryActions = document.createElement('div');
    categoryActions.style.cssText = 'display:flex; gap:4px;';

    const editCategoryBtn = document.createElement('button');
    editCategoryBtn.textContent = '✏️';
    editCategoryBtn.title = 'Editar Categoria';
    editCategoryBtn.style.cssText = 'background:#ffc107; color:white; border:none; padding:4px 8px; border-radius:4px; cursor:pointer; font-size:12px;';
    editCategoryBtn.onclick = (e) => { e.stopPropagation(); editCategory(categoryName); };

    const deleteCategoryBtn = document.createElement('button');
    deleteCategoryBtn.textContent = '🗑️';
    deleteCategoryBtn.title = 'Excluir Categoria';
    deleteCategoryBtn.style.cssText = 'background:#dc3545; color:white; border:none; padding:4px 8px; border-radius:4px; cursor:pointer; font-size:12px;';
    deleteCategoryBtn.onclick = (e) => { e.stopPropagation(); deleteCategory(categoryName); };

    categoryActions.appendChild(editCategoryBtn);
    categoryActions.appendChild(deleteCategoryBtn);
    categoryHeader.appendChild(categoryActions);
    categoryDiv.appendChild(categoryHeader);

    const subcategoriesList = document.createElement('div');
    subcategoriesList.style.marginTop = '8px';
    subcategoriesList.classList.add('ml-messages-list');

    Object.entries(category.subcategories).forEach(([subName, subItem]) => {
      const subMessage = typeof subItem === 'string' ? subItem : subItem.message;
      const subColor = (typeof subItem === 'object' && subItem.color) ? subItem.color : (category.color || '#007bff');

      const subDiv = document.createElement('div');
      subDiv.style.cssText = `
        display:flex; justify-content:space-between; align-items:center;
        padding:6px 8px; background:white;
        border:1px solid #eee; border-left:5px solid ${subColor};
        border-radius:4px; margin-bottom:4px; cursor:move;
      `;
      subDiv.draggable = true;
      subDiv.dataset.category = categoryName;
      subDiv.dataset.subcategory = subName;

      subDiv.addEventListener('dragstart', (e) => { draggedSubItem = { category: categoryName, subcategory: subName }; e.target.style.opacity = '0.5'; });
      subDiv.addEventListener('dragend', (e) => { e.target.style.opacity = '1'; draggedSubItem = null; draggedOverSubItem = null; });
      subDiv.addEventListener('dragover', (e) => {
        e.preventDefault();
        if (draggedSubItem && draggedSubItem.category === categoryName && draggedSubItem.subcategory !== subName) {
          draggedOverSubItem = { category: categoryName, subcategory: subName };
          e.target.style.borderTop = '3px solid #007bff';
        }
      });
      subDiv.addEventListener('dragleave', (e) => { e.target.style.borderTop = '1px solid #eee'; });
      subDiv.addEventListener('drop', (e) => {
        e.preventDefault();
        e.target.style.borderTop = '1px solid #eee';
        if (draggedSubItem && draggedOverSubItem && draggedSubItem.category === draggedOverSubItem.category && draggedSubItem.subcategory !== draggedOverSubItem.subcategory) {
          const arr = Object.entries(messageData.categories[categoryName].subcategories);
          const di = arr.findIndex(([n]) => n === draggedSubItem.subcategory);
          const oi = arr.findIndex(([n]) => n === draggedOverSubItem.subcategory);
          const [removed] = arr.splice(di, 1);
          arr.splice(oi, 0, removed);
          messageData.categories[categoryName].subcategories = {};
          arr.forEach(([n, d]) => { messageData.categories[categoryName].subcategories[n] = d; });
          saveData(); updateItemsList();
        }
        draggedSubItem = null; draggedOverSubItem = null;
      });

      const subTextContainer = document.createElement('div');
      subTextContainer.textContent = subName;
      subTextContainer.style.cssText = 'flex:1; cursor:pointer;';
      subTextContainer.onclick = () => { insertMessage(subMessage); toggleMenu(); };

      const subActions = document.createElement('div');
      subActions.style.cssText = 'display:flex; gap:4px;';

      const editSubBtn = document.createElement('button');
      editSubBtn.textContent = '✏️';
      editSubBtn.title = 'Editar';
      editSubBtn.style.cssText = 'background:#ffc107; color:white; border:none; padding:2px 6px; border-radius:3px; cursor:pointer; font-size:10px;';
      editSubBtn.onclick = (e) => { e.stopPropagation(); editSubcategory(categoryName, subName, subMessage, subColor); };

      const deleteSubBtn = document.createElement('button');
      deleteSubBtn.textContent = '🗑️';
      deleteSubBtn.title = 'Excluir';
      deleteSubBtn.style.cssText = 'background:#dc3545; color:white; border:none; padding:2px 6px; border-radius:3px; cursor:pointer; font-size:10px;';
      deleteSubBtn.onclick = (e) => { e.stopPropagation(); deleteSubcategory(categoryName, subName); };

      subActions.appendChild(editSubBtn);
      subActions.appendChild(deleteSubBtn);
      subDiv.appendChild(subTextContainer);
      subDiv.appendChild(subActions);
      subcategoriesList.appendChild(subDiv);
    });

    categoryDiv.appendChild(subcategoriesList);
    list.appendChild(categoryDiv);
  });
}

// ============================================================
// MODAIS DE EDIÇÃO
// ============================================================

function editCategory(categoryName) {
  const category = messageData.categories[categoryName];
  if (!category) return;

  const modal = document.createElement('div');
  modal.style.cssText = 'position:fixed; inset:0; background:rgba(0,0,0,0.5); display:flex; align-items:center; justify-content:center; z-index:10003;';

  const content = document.createElement('div');
  content.style.cssText = 'background:white; padding:20px; border-radius:8px; box-shadow:0 4px 16px rgba(0,0,0,0.2); width:400px; max-width:90%;';
  content.innerHTML = `
    <h3 style="margin-top:0; margin-bottom:15px; color:#333;">Editar Categoria: ${categoryName}</h3>
    <div style="margin-bottom:10px;">
      <label style="display:block; margin-bottom:5px; font-weight:bold;">Novo Nome:</label>
      <input type="text" id="edit-category-name" value="${categoryName}" style="width:100%; padding:8px; border:1px solid #ddd; border-radius:4px; box-sizing:border-box;">
    </div>
    <div style="margin-bottom:10px;">
      <label style="display:block; margin-bottom:5px; font-weight:bold;">Ícone (emoji):</label>
      <input type="text" id="edit-category-icon" value="${category.icon || ''}" style="width:100%; padding:8px; border:1px solid #ddd; border-radius:4px; box-sizing:border-box;">
    </div>
    <div style="margin-bottom:20px;">
      <label style="display:block; margin-bottom:5px; font-weight:bold;">Cor:</label>
      <input type="color" id="edit-category-color" value="${category.color || '#007bff'}" style="width:100%; height:36px; border:1px solid #ddd; border-radius:4px; cursor:pointer;">
    </div>
    <div style="text-align:right;">
      <button id="cancel-edit" style="background:#6c757d; color:white; border:none; padding:8px 16px; border-radius:4px; cursor:pointer; margin-right:10px;">Cancelar</button>
      <button id="save-edit" style="background:#28a745; color:white; border:none; padding:8px 16px; border-radius:4px; cursor:pointer;">Salvar</button>
    </div>
  `;
  modal.appendChild(content);
  document.body.appendChild(modal);

  document.getElementById('cancel-edit').onclick = () => document.body.removeChild(modal);
  document.getElementById('save-edit').onclick = () => {
    const newName = document.getElementById('edit-category-name').value.trim();
    const newIcon = document.getElementById('edit-category-icon').value.trim();
    const newColor = document.getElementById('edit-category-color').value;
    if (!newName) { alert('Nome não pode ser vazio'); return; }
    if (newName !== categoryName && messageData.categories[newName]) { alert('Já existe uma categoria com este nome'); return; }
    if (newName !== categoryName) {
      messageData.categories[newName] = { ...category, icon: newIcon, color: newColor };
      delete messageData.categories[categoryName];
    } else {
      messageData.categories[categoryName].icon = newIcon;
      messageData.categories[categoryName].color = newColor;
    }
    saveData(); updateCategorySelect(); updateItemsList();
    document.body.removeChild(modal);
    alert('Categoria atualizada!');
  };
  modal.onclick = (e) => { if (e.target === modal) document.body.removeChild(modal); };
}

function editSubcategory(categoryName, subcategoryName, currentMessage, currentColor) {
  const modal = document.createElement('div');
  modal.style.cssText = 'position:fixed; inset:0; background:rgba(0,0,0,0.5); display:flex; align-items:center; justify-content:center; z-index:10003;';

  const content = document.createElement('div');
  content.style.cssText = 'background:white; padding:20px; border-radius:8px; box-shadow:0 4px 16px rgba(0,0,0,0.2); width:500px; max-width:90%;';
  content.innerHTML = `
    <h3 style="margin-top:0; margin-bottom:15px; color:#333;">Editar: ${subcategoryName}</h3>
    <div style="margin-bottom:10px;">
      <label style="display:block; margin-bottom:5px; font-weight:bold;">Nome:</label>
      <input type="text" id="edit-subcategory-name" value="${subcategoryName}" style="width:100%; padding:8px; border:1px solid #ddd; border-radius:4px; box-sizing:border-box;">
    </div>
    <div style="margin-bottom:10px;">
      <label style="display:block; margin-bottom:5px; font-weight:bold;">Cor da linha lateral:</label>
      <input type="color" id="edit-subcategory-color" value="${currentColor}" style="width:100%; height:36px; border:1px solid #ddd; border-radius:4px; cursor:pointer;">
    </div>
    <div style="margin-bottom:20px;">
      <label style="display:block; margin-bottom:5px; font-weight:bold;">Mensagem:</label>
      <textarea id="edit-subcategory-message" style="width:100%; height:150px; padding:8px; border:1px solid #ddd; border-radius:4px; resize:vertical; box-sizing:border-box;">${currentMessage}</textarea>
    </div>
    <div style="text-align:right;">
      <button id="cancel-edit" style="background:#6c757d; color:white; border:none; padding:8px 16px; border-radius:4px; cursor:pointer; margin-right:10px;">Cancelar</button>
      <button id="save-edit" style="background:#28a745; color:white; border:none; padding:8px 16px; border-radius:4px; cursor:pointer;">Salvar</button>
    </div>
  `;
  modal.appendChild(content);
  document.body.appendChild(modal);

  document.getElementById('cancel-edit').onclick = () => document.body.removeChild(modal);
  document.getElementById('save-edit').onclick = () => {
    const newName = document.getElementById('edit-subcategory-name').value.trim();
    const newMessage = document.getElementById('edit-subcategory-message').value.trim();
    const newColor = document.getElementById('edit-subcategory-color').value;
    if (!newName) { alert('Nome não pode ser vazio'); return; }
    if (!newMessage) { alert('Mensagem não pode ser vazia'); return; }
    if (newName !== subcategoryName && messageData.categories[categoryName].subcategories[newName]) { alert('Já existe uma mensagem com este nome'); return; }
    if (newName !== subcategoryName) delete messageData.categories[categoryName].subcategories[subcategoryName];
    messageData.categories[categoryName].subcategories[newName] = { message: newMessage, color: newColor };
    saveData(); updateItemsList();
    document.body.removeChild(modal);
    alert('Mensagem atualizada!');
  };
  modal.onclick = (e) => { if (e.target === modal) document.body.removeChild(modal); };
}

function deleteCategory(categoryName) {
  if (confirm(`Excluir a categoria "${categoryName}" e todas suas mensagens?`)) {
    delete messageData.categories[categoryName];
    saveData(); updateCategorySelect(); updateItemsList();
  }
}

function deleteSubcategory(categoryName, subcategoryName) {
  if (confirm(`Excluir a mensagem "${subcategoryName}"?`)) {
    delete messageData.categories[categoryName].subcategories[subcategoryName];
    saveData(); updateItemsList();
  }
}

function clearAllData() {
  if (confirm('Excluir TODAS as mensagens? Esta ação não pode ser desfeita.')) {
    messageData.categories = {};
    saveData(); updateCategorySelect(); updateItemsList();
    alert('Todos os dados foram limpos!');
  }
}

// ============================================================
// INSERÇÃO DE MENSAGEM
// ============================================================

function getFirstNameFromPage() {
  let customerName = '';

  let nameElement = document.querySelector('#user_header p');
  if (nameElement) customerName = nameElement.textContent.trim().split(' ')[0];

  if (!customerName) {
    nameElement = document.querySelector('.andes-message-card__header__title span.andes-text_size_large');
    if (nameElement) {
      const match = nameElement.textContent.trim().match(/Conversa com (.+)/);
      customerName = match ? match[1].split(' ')[0] : nameElement.textContent.trim().split(' ')[0];
    }
  }

  if (!customerName) {
    nameElement = document.querySelector('[data-testid="buyer-name"], .buyer-info__name, .user-info__name');
    if (nameElement) customerName = nameElement.textContent.trim().split(' ')[0];
  }

  if (!customerName) {
    nameElement = document.querySelector('a.nav-profile-menu-trigger span.nav-menu-label');
    if (nameElement) customerName = nameElement.textContent.trim().split(' ')[0];
  }

  if (!customerName) {
    const buyerLabel = Array.from(document.querySelectorAll('span, div, p'))
      .find(el => el.textContent.includes('Comprador') || el.textContent.includes('Cliente'));
    if (buyerLabel && buyerLabel.nextElementSibling)
      customerName = buyerLabel.nextElementSibling.textContent.trim().split(' ')[0];
  }

  customerName = customerName.replace(/^(Sr\.|Sra\.)\s*/i, '').trim();

  // Formata: primeira letra maiúscula, restante minúsculo
  if (customerName) {
    customerName = customerName.charAt(0).toUpperCase() + customerName.slice(1).toLowerCase();
  }

  return customerName;
}

function insertMessage(message) {
  const campo = document.querySelector('textarea.sc-textarea') ||
    document.querySelector('textarea') ||
    document.querySelector('[contenteditable="true"]') ||
    document.querySelector('input[type="text"]');

  let finalMessage = message;

  if (finalMessage.includes('[NOME_CLIENTE]')) {
    const customerFirstName = getFirstNameFromPage();
    finalMessage = customerFirstName
      ? finalMessage.replace(/\[NOME_CLIENTE\]/g, customerFirstName)
      : finalMessage.replace(/\[NOME_CLIENTE\]/g, '').trim();
  }

  if (campo) {
    campo.focus();
    if (campo.tagName === 'TEXTAREA' || campo.tagName === 'INPUT') {
      campo.value = finalMessage;
      campo.dispatchEvent(new Event('input', { bubbles: true }));
      campo.dispatchEvent(new Event('change', { bubbles: true }));
    } else {
      campo.textContent = finalMessage;
      campo.dispatchEvent(new Event('input', { bubbles: true }));
    }
  } else {
    navigator.clipboard.writeText(finalMessage)
      .then(() => alert('Campo de texto não encontrado. Mensagem copiada para a área de transferência.'))
      .catch(() => alert('Não foi possível encontrar campo de texto ou copiar mensagem.'));
  }
}

// ============================================================
// BOOT — inicialização
// ============================================================

loadData();

// Verifica se há mensagens padrão para aplicar (primeira instalação)
chrome.runtime.sendMessage({ action: 'get_default_messages' }, (res) => {
  if (res && res.data) {
    try {
      const imported = JSON.parse(res.data);
      if (imported.categories && Object.keys(messageData.categories).length === 0) {
        messageData = imported;
        saveData();
        console.log('[Passo-Largo] Mensagens padrão aplicadas com sucesso!');
      }
    } catch(e) {
      console.warn('[Passo-Largo] Erro ao aplicar mensagens padrão:', e.message);
    }
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', renderButton);
  } else {
    renderButton();
  }
});

// Listener de mensagens do popup/background
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'openEditor') openEditor();
});
